import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import {
  createStackNavigator,
  StackScreenProps,
} from "@react-navigation/stack";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import HomePage from "./pages/HomePage";
import Colors from "../constants/Colors";
import { StatusBar, useColorScheme } from "react-native";
import MapboxGL from '@rnmapbox/maps';

MapboxGL.setAccessToken('sk.eyJ1IjoicGVuemVybyIsImEiOiJjbTNneHI2dGEwYXI2MnFzZGU4eG5pemJ0In0.ckCUJMHh8bP1xZY3fgKo5w');


export type RootStackParamList = {
  Login: undefined;
  Register: undefined;
  Home: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();

const App = () => {
  const theme = useColorScheme() || "light";

  return (
    <NavigationContainer>
      <StatusBar
        barStyle={theme === 'dark' ? 'light-content' : 'dark-content'}
        backgroundColor={Colors[theme].primary}
      />
      <Stack.Navigator
        initialRouteName="Login"
        screenOptions={{
          headerStyle: { backgroundColor: Colors[theme].primary, height: 50 },
          headerTintColor: Colors[theme].buttonText,
          headerTitleStyle: { fontWeight: "bold" },
        }}
      >
        <Stack.Screen name="Login" component={LoginPage} options={{ title: "Login" }} />
        <Stack.Screen name="Register" component={RegisterPage} options={{ title: "Register" }} />
        <Stack.Screen name="Home" component={HomePage} options={{ title: "Home" }} />
        </Stack.Navigator>
      {/* <Stack.Navigator>
        <Stack.Screen
          name="Home"
          component={HomePage}
          options={{ title: "Home" }}
        />
      </Stack.Navigator> */}
    </NavigationContainer>
  );
};

export default App;
