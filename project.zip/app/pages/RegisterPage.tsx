import React, { useState } from "react";
import { TextInput, TouchableOpacity, Alert, StyleSheet } from "react-native";
import { ThemedText } from "../../components/ThemedComponents/ThemedText";
import { ThemedView } from "../../components/ThemedComponents/ThemedView";
import Colors from "../../constants/Colors";
import { useColorScheme } from "react-native";
import { StackScreenProps } from "@react-navigation/stack";
import { RootStackParamList } from "../index";

type RegisterPageProps = StackScreenProps<RootStackParamList, "Register">;

const RegisterPage: React.FC<RegisterPageProps> = ({ navigation }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const theme = useColorScheme() || "light";

  const handleRegister = () => {
    if (!name || !email || !password) {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert("Invalid Email", "Please enter a valid email address");
      return;
    }

    Alert.alert("Success", `Registered with\nName: ${name}\nEmail: ${email}`);
  };

  return (
    <ThemedView style={styles.container} lightColor={Colors.light.background} darkColor={Colors.dark.background}>
      <ThemedText style={styles.title} type="title" lightColor={Colors.light.text} darkColor={Colors.dark.text}>
        Register
      </ThemedText>
      <TextInput
        style={[styles.input, { backgroundColor: Colors[theme].inputBackground, borderColor: Colors[theme].border }]}
        placeholder="Name"
        placeholderTextColor={Colors[theme].text}
        onChangeText={setName}
        value={name}
      />
      <TextInput
        style={[styles.input, { backgroundColor: Colors[theme].inputBackground, borderColor: Colors[theme].border }]}
        placeholder="Email"
        placeholderTextColor={Colors[theme].text}
        onChangeText={setEmail}
        value={email}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={[styles.input, { backgroundColor: Colors[theme].inputBackground, borderColor: Colors[theme].border }]}
        placeholder="Password"
        placeholderTextColor={Colors[theme].text}
        onChangeText={setPassword}
        value={password}
        secureTextEntry
      />
      <TouchableOpacity style={[styles.button, { backgroundColor: Colors[theme].primary }]} onPress={handleRegister}>
        <ThemedText style={styles.buttonText} type="default" lightColor={Colors.light.buttonText} darkColor={Colors.dark.buttonText}>
          Register
        </ThemedText>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate("Login")}>
        <ThemedText style={styles.linkText} lightColor={Colors.light.primary} darkColor={Colors.dark.primary}>
          Already have an account? Login
        </ThemedText>
      </TouchableOpacity>
    </ThemedView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  title: {
    marginBottom: 20,
    fontSize: 24,
  },
  input: {
    width: "100%",
    padding: 15,
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 15,
    textAlign: "center",
  },
  button: {
    width: "100%",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
  },
  buttonText: {
    fontWeight: "bold",
  },
  linkText: {
    marginTop: 15,
    textDecorationLine: "underline",
  },
});

export default RegisterPage;
