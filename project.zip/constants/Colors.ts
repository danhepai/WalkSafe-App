const tintColorLight = "#009454";
const tintColorDark = "#BBFFDA";

const Colors = {
  light: {
    primary: "#009454",
    secondary: "#FF6B3F", // Brighter orange-red for a more vibrant accent
    background: "#F8FAFB", // Soft, light gray background for a clean look
    text: "#333333", // Dark gray for comfortable readability
    buttonText: "#FFFFFF", // White for high contrast with buttons
    border: "#E0E0E0", // Light gray for subtle borders
    lightGreen: "#D8FFEE", // Keep the light green for accents
    inputBackground: "#FFFFFF", // White for input fields to stand out
    icon: tintColorLight,
  },
  dark: {
    primary: "#009454",
    secondary: "#FF5722",
    background: "#121212", 
    text: "#E0E0E0", 
    buttonText: "#FFFFFF",
    border: "#333333", 
    lightGreen: "#007C52", 
    inputBackground: "#1E1E1E", 
    icon: tintColorDark,
  },
};

export default Colors;