import MapboxGL from "@rnmapbox/maps";
import { View, StyleSheet } from "react-native";

const Map = () =>{

  return (
<MapboxGL.MapView style={styles.map}>
  <MapboxGL.Camera zoomLevel={10} centerCoordinate={[-122.4324, 37.78825]} />
  <MapboxGL.PointAnnotation id="marker" coordinate={[-122.4324, 37.78825]}>
    <View style={styles.annotationContainer}>
      <View style={styles.annotationFill} />
    </View>
  </MapboxGL.PointAnnotation>
</MapboxGL.MapView>
  );
}

const styles = StyleSheet.create({
  map:{
    flex: 1,
    width: '100%',
    height: '80%',
  },
  annotationContainer: {
    width: 30,
    height: 30,
    backgroundColor: 'blue',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  annotationFill: {
    width: 15,
    height: 15,
    borderRadius: 7.5,
    backgroundColor: 'white',
  },
});

export default Map;